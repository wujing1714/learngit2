#ifndef ONMOUSE_H
#define ONMOUSE_H
#include "mainProcess.h"
void on_mouse(int event, int x, int y, int flags, void* param);
#endif